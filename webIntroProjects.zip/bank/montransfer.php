<?php
	session_start();
	
	$MySQLdb = new PDO("mysql:host=127.0.0.1;dbname=bank", "root", "");
	$MySQLdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	$msg = "";

	if (isset($_POST["toUser"])){
		$cursor = $MySQLdb->prepare("SELECT * FROM users WHERE username=:username");
		$cursor->execute( array(":username"=>$_POST["toUser"]));


		if($cursor->rowCount()){
			$msg = "transfered";
		}else{

			$msg = "username incorrect";

		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Money Transfer</title>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<style>
body {
  background-image: url('mon.jpg');
  background-repeat: no-repeat;
  background-size: cover;

}
</style>
</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="#">B-Bank</a>
		</div>
		<ul class="nav navbar-nav">
			<li><a href="main.php">Main</a></li>
			<li><a href="profupdate.php">Update Profile</a></li>
			<li><a href="transfers.php">Total transactions</a></li>
			<li><a href="logout.php">Exit</a></li>
		</ul>
	</div>
</nav>

		<form action="montransfer.php" class="transfer-form" method="POST">
				<div class="transfer-form" style="text-align:center">
						<h2>Money Transfer</h2>
						<h2><?php echo 'User: ' . $_SESSION["username"]; ?></h2>
						<div style="text-align:center" >
							<span><b>Balance:  </b></span><input type="number" id="balance" value="">
						</div>
					</div>

					<br><br>

				<div class="transfer-form" style="text-align:center" >
					<span><b>Username:  </b></span><input type="text" name="toUser" id="username" placeholder="To Who?" required>
				</div>

					<br><br>

				<div class="tranfer-form" style="text-align:center">
					<span><b>Amount:  </b></span><input type="number" name="amount" id="amount" placeholder="How much?" required>
				</div>

					<br><br>

				<div class="transfer-form" style="text-align:center">
					<input id="ckb" type="checkbox" name="sure" required>
						 <b>Are You Sure?</b>
				</div>

					<br><br>

				<div class="transfer-form" style="text-align:center">
					<button type="submit" id="submit" name="submit">
						Submit
					</button>
				</div>

				<div class="transfer-form" style="text-align:center">
					<h4>
						<?php echo $msg; ?>
					</h4>
				</div>

					<br><br>

				<div class="transfer-form" style="text-align:center">
					<a class="txt1" href="#">
						Need A Loan From <b>B-Bank</b>?
					</a>
				</div>

			</form>

<script>
	$.post("api.php", {"action":"get_balance"},function(data){
		$("#balance").val(data.balance);

	});

	$("#submit").click(function(){
		$amount = parseInt($("#amount").val())
		$balance = parseInt($("#balance").val())

		if ($amount > $balance){
			alert("Enter amount that you have.");

		}else if ($amount < 0){
			alert("Enter correct amount");

		}else {
			$.post("api.php", {"action":"balanceUpdate", "username":$("#username").val(), "amount":$("#amount").val()},function(data){

			});
		}
	});


</script>
</body>
</html>
