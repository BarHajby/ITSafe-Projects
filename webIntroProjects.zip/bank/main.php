<?php
	session_start();
	if (isset($_SESSION["count"])){
		$_SESSION["count"]++;

	}else{
		$_SESSION["count"] = 1;

	}



?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Main</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<style>
body {
  background-image: url('mainback.jpg');
  background-repeat: no-repeat;
  background-size: cover;

}
</style>
</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="#">B-Bank</a>
		</div>
		<ul class="nav navbar-nav">
			<li class="active"><a href="#">Main</a></li>
			<li><a href="montransfer.php">Money Transfer</a></li>
			<li><a href="profupdate.php">Update Profile</a></li>
			<li><a href="transfers.php">Total transactions</a></li>
			<li><a href="logout.php">Exit</a></li>
		</ul>
	</div>
</nav>

				<div style="text-align:center">
					<h3> Main Page </h3>
					<hr/>
				</div>
				<form action="#" method="post">
					<div class="container-fluid">

					<div style="text-align:center">
					<h2 id="account">
						<?php echo 'Welcome: ' . $_SESSION["username"]; ?>
					</h2>
					</div>

						<br><br>

					<div id="id" style="text-align:center">
						<label for="id"><b>ID:</b></label>
						<input id="id_num" for="id" value="" disabled>
					</div>

							<br><br>

					<div id="addr" style="text-align:center">
						<label for="address"><b>Address:</b></label>
						<input for="address" id="address"  value="" disabled>
					</div>

							<br><br>

					<div id="money" style="text-align:center">
					<label for="money"><b>Balance:</b></label>
					<input id="balance" for="money" disabled>
					</div>

							<br><br>

					<div id="Email" style="text-align:center">
					<label for="Email"><b>Email:</b></label>
					<input for="Email" id="email" value="" disabled>
					</div>

							<br><br>

					<div id="telephone" style="text-align:center">
					<label for="telephone"><b>Phone Number:</b></label>
					<input for="telephone" id="phone" value="" disabled>
					</div>

							<br><br>

					<div style="text-align:center">
						<button>
								<a href="profupdate.php">
									update profile?
								</a>
						</button>
					</div>
					</div>
				</form>

<script>
	$(".login100-form-btn").click(function(){
  	alert("we've sent Loan plan to your E-mail");
	});
	$.post("api.php", {"action":"get_all"},function(data){
		$("#id_num").val(data.id_num);
		$("#address").val(data.address);
		$("#balance").val(data.balance);
		$("#phone").val(data.phone);
		$("#email").val(data.email);
		console.log(data);
	});

		$("#phoneUpdate").click(function(){
			$.post("api.php", {"action":"phoneUpdate","phone":$("#phone").val()},function(data){
				console.log(data);
			});
		});

		$("#userDel").click(function(){
			$.post("api.php", {"action":"userDel"},function(data){
				if (data == "deleted"){
					location.href = "login.php";

				}
			});
		});

</script>
</body>
</html>
