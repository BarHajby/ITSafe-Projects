<?php
	$msg = "";
	session_start();

//check if got any request
	if (isset($_POST["action"])){

		$MySQLdb = new PDO("mysql:host=127.0.0.1;dbname=bank", "root", "");
		$MySQLdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//verify that the action sent is indeed register
		if ($_POST["action"] == "register"){
//checking if username exist already in the DB
			$cursor = $MySQLdb->prepare("SELECT * FROM users WHERE username=:username");
			$cursor->execute( array(":username"=>$_POST["username"]));

			if($cursor->rowCount()){

				exit("Username already exist, please login");


			}


				else if ($_POST["pass"] == $_POST["pass1"]){

					$cursor = $MySQLdb->prepare("INSERT INTO `users`(`username`, `password`, `email`, `phone`, `address`) VALUES (:username,:password,:email,:phone,:address)");
					$cursor->execute(array (":username"=>$_POST["username"], ":password"=>$_POST["pass"], ":email"=>$_POST["email"], ":phone"=>$_POST["phone"], ":address"=>$_POST["address"]));


					}if($cursor->rowCount()){

						$row = $cursor->fetch();
						$_SESSION["username"] = $_POST['username'];
						$msg = "welcome ". $_SESSION["username"];
						header("location: main.php");


					}else{

					$msg = "ERROR: the passwords is not equal";
				}

		}


		}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">B-Bank</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="register.php">Register</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </div>
</nav>

    <div class="main">
        <!-- Sign up form -->
        <section class="signup">
            <div class="container-fluid">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Register</h2>
                        <form action="register.php" method="POST" class="register-form" id="register-form">
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="username" id="name" placeholder="Username"/>
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Your Email"/>
                            </div>
                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="pass" id="pass" placeholder="Password"/>
                            </div>

                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="pass1" id="re_pass" placeholder="Repeat your password"/>
                            </div>
                            <div class="form-group">
                                <label for="phone"><i class="zmdi zmdi-lock"></i></label>
                                <input type="number" name="phone" id="phone" placeholder="Phone Number"/>
                            </div>
                            <div class="form-group">
                                <label for="address"><i class="zmdi zmdi-lock"></i></label>
                                <input type="text" name="address" id="address" placeholder="Address"/>
                            </div>
                            <div class="form-group">
                                <input type="checkbox" name="agree-term" id="agree-term" class="agree-term" />
                                <label for="agree-term" class="label-agree-term"><span><span></span></span>Are you above 18?</label>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="action" id="signup" class="form-submit" value="register"/>
                            </div>

														<div class="form-group form-button">
                                <h3> <?php echo $msg; ?> </h3>
                            </div>

                            <div>
                                <a href="login.php" class="signup-image-link">I am already member</a>
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="images/signup-image.jpg" alt="sing up image"></figure>
                    </div>
                </div>
            </div>
        </section>



    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
