<?php
	$msg = "";
	session_start();

	if (isset($_POST["action"])){

		$MySQLdb = new PDO("mysql:host=127.0.0.1;dbname=bank", "root", "");
		$MySQLdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		if ($_POST["action"] == "login"){

			$cursor = $MySQLdb->prepare("SELECT * FROM users WHERE username=:username AND password=:password");
			$cursor->execute( array(":username"=>$_POST["username"], ":password"=>$_POST["password"]));


				if($cursor->rowCount()){

					$row = $cursor->fetch();
					$_SESSION["username"] = $row['username'];
					$msg = "welcome ". $_SESSION["username"];
					header("location: main.php");

				}else{

					$msg = "username or password incorrect";

				}


		}
	}


?>
<!DOCTYPE html>
        <html lang="en">
        <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Login</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">B-Bank</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="login.php">Login</a></li>
            <li><a href="register.php">Register</a></li>
        </ul>
    </div>
</nav>

<div class="main">

    <!-- Sing in  Form -->
    <section class="sign-in">
        <div class="container-fluid">
            <div class="signin-content">
                <div class="signin-image">
                    <figure><img src="images/signin-image.jpg" alt="sing up image"></figure>
                </div>

                <div class="signin-form">
                    <h2 class="form-title">Login</h2>
                    <form action="login.php" method="POST" class="register-form" id="login-form">
                        <div class="form-group">
                            <label for="your_name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                            <input type="text" name="username" id="your_name" placeholder="Username"/>
                        </div>
                        <div class="form-group">
                            <label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
                            <input type="password" name="password" id="your_pass" placeholder="Password"/>
                        </div>
                        <div class="form-group">
                            <input type="checkbox" name="remember-me" id="remember-me" class="agree-term" />
                            <label for="remember-me" class="label-agree-term"><span><span></span></span>Remember me</label>
                        </div>
                        <div class="form-group form-button">
                            <input type="submit" name="action" id="signin" class="form-submit" value="login"/>
                        </div>
												<p>
														<?php echo $msg; ?>
												</p>
                        <div>
                            <a href="register.php" class="signup-image-link">Create an account</a>
                        </div>
                        <button id="forgot">
                            <a>Forgot Password?</a>
                        </button>
                    </form>

                </div>
            </div>
        </div>
    </section>

</div>

<!-- JS -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="js/main.js"></script>

<script>
    $("#forgot").click(function(){
  			alert("A reset code has sent to your Email, Please check soon");
		});
</script>





</body>
</html>
