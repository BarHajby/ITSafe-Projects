<?php
	session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>All Transfers</title>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<style>
body {
  background-image: url('trans.jpg');
  background-repeat: no-repeat;
  background-size: cover;

}
</style>
<style>
table, th, td {
  border:1px solid black;
  text-align:center;
  background-color: LightBlue;
}
.center {
  margin-left: auto;
  margin-right: auto;
}
</style>
</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="#">B-Bank</a>
		</div>
		<ul class="nav navbar-nav">
			<li><a href="main.php">Main</a></li>
			<li><a href="profupdate.php">Update Profile</a></li>
      <li><a href="montransfer.php">transfer money</a></li>
			<li><a href="logout.php">Exit</a></li>
		</ul>
	</div>
</nav>



						<h2 style="text-align:center; background-color: white">All Transfers Live Updated</h2>
            <h2 style="text-align:center; background-color: white"><?php date_default_timezone_set('Asia/Jerusalem'); echo $today = date("F j, Y, g:i a"); ?></h2>
            <div>
            <table style="width:70%" class="center">
                <tr>
                  <th><u>Transfer ID:</u></th>
                  <th><u>From user:</u></th>
                  <th><u>To user:</u></th>
                  <th><u>amount:</u></th>
                </tr>
                <?php
                $conn = mysqli_connect("localhost", "root", "", "bank");
                if ($conn-> connect_error){
                  die("connection failed:". $conn-> connect_error);
                }

                $sql = "SELECT id, from_user, to_user, amount from transactions";
                $result = $conn-> query($sql);

                if ($result-> num_rows > 0){
                  while ($row = $result-> fetch_assoc()){
                    echo "<tr><th>". $row["id"] . "<th>" . $row["from_user"]. "<th>". $row["to_user"]. "<th>". $row["amount"]. "</td></th>";
                  }
                  echo "</table>";
                }
                else {
                  echo "0";
                }
                ?>
              </table>
            </div>
<script>
	$.post("api.php", {"action":"get_balance"},function(data){
		$("#balance").val(data.balance);

	});

	$("#submit").click(function(){
		$amount = parseInt($("#amount").val())
		$balance = parseInt($("#balance").val())

		if ($amount > $balance){
			alert("Enter amount that you have.");

		}else if ($amount < 0){
			alert("Enter correct amount");

		}else {
			$.post("api.php", {"action":"balanceUpdate", "username":$("#username").val(), "amount":$("#amount").val()},function(data){

			});
		}
	});


</script>
</body>
</html>
