<?php

session_start();

$MySQLdb = new PDO("mysql:host=127.0.0.1;dbname=bank", "root", "");
$MySQLdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

header("content-type: application/json");

if (isset($_POST["action"])){

		switch ($_POST["action"]){

			case "get_all":
				$cursor = $MySQLdb->prepare("SELECT * FROM users WHERE username=:username");
				$cursor->execute( array(":username"=>$_SESSION["username"]) );

				echo json_encode($cursor->fetch());

				break;

			case "phoneUpdate":
				$cursor = $MySQLdb->prepare("UPDATE users SET phone=:phone WHERE username=:username");
				$cursor->execute( array(":phone"=>$_POST["phone"], ":username"=>$_SESSION["username"]) );

				break;
			case "addrUpdate":
				$cursor = $MySQLdb->prepare("UPDATE users SET address=:address WHERE username=:username");
				$cursor->execute( array(":address"=>$_POST["address"], ":username"=>$_SESSION["username"]) );

				break;

			case "emailUpdate":
				$cursor = $MySQLdb->prepare("UPDATE users SET email=:email WHERE username=:username");
				$cursor->execute( array(":email"=>$_POST["email"], ":username"=>$_SESSION["username"]) );

				break;

			case "get_balance":
				$cursor = $MySQLdb->prepare("SELECT balance FROM users WHERE username=:username");
				$cursor->execute( array(":username"=>$_SESSION["username"]) );

				echo json_encode($cursor->fetch());

				break;


			case "balanceUpdate":
				$cursor = $MySQLdb->prepare("SELECT * FROM users WHERE username=:username");
				$cursor->execute( array(":username"=>$_POST["username"]));

				echo json_encode($cursor->fetch());

					if ($cursor->rowcount()){

						$cursor = $MySQLdb->prepare("UPDATE users SET balance = balance + :amount WHERE username=:username");
						$cursor->execute( array(":amount"=>$_POST["amount"], ":username"=>$_POST["username"]));

						$cursor = $MySQLdb->prepare("UPDATE users SET balance = balance - :amount WHERE username=:username");
						$cursor->execute( array(":amount"=>$_POST["amount"], ":username"=>$_SESSION["username"]));

						$cursor = $MySQLdb->prepare("INSERT INTO `transactions`(`to_user`, `from_user`, `amount`) VALUES (:to_user,:from_user,:amount)");
						$cursor->execute(array (":to_user"=>$_POST["username"], ":from_user"=>$_SESSION["username"], ":amount"=>$_POST["amount"]));


					}
				break;




		}

}
?>
