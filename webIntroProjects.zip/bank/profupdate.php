<?php
	session_start();
	if (isset($_SESSION["count"])){
		$_SESSION["count"]++;

	}else{
		$_SESSION["count"] = 1;

	}


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Profile Update</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<style>
body {
  background-image: url('mon.jpg');
  background-repeat: no-repeat;
  background-size: cover;

}
</style>
</head>
<body>


<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="#">B-Bank</a>
		</div>
		<ul class="nav navbar-nav">
			<li><a href="main.php">Main</a></li>
			<li><a href="montransfer.php">Money Transfer</a></li>
			<li><a href="transfers.php">Total transactions</a></li>
			<li><a href="logout.php">Exit</a></li>
		</ul>
	</div>
</nav>
	<br><br>


<!-- -->
				<form action="#" method="post" >
					<div style="text-align:center">
						<h2 style="color:black;background-color:white"> Update Profile: <?php echo $_SESSION["username"]; ?> </h2>
						<hr/>
					</div>
						<br><br>

					<div id="user"class="update-form" style="text-align:center">
						<label for="lname"> <b>Username:</b></label>
						<input type="text" id="username" value="">
					</div>
					<br><br>

					<div id="ID" class="update-form" style="text-align:center">
						<label for="ID"> <b>Bank ID:</b></label>
						<input id="id_num" type="number" class="id" value="" disabled>
					</div>
							<br><br>
					<div id="addr" class="update-form" style="text-align:center">
						<label for="address"> <b>Address:</b></label>
						<input type="text" id="address" value="">
						<input type="submit" value="Update" id="addrUpdate">
					</div>
							<br><br>

					<div id="mobile" class="update-form" style="text-align:center">
						<label for="mobile"> <b>Mobile:</b></label>
						<input id="phone" type="tel" class="mobile" value="">
						<input type="submit" value="Update" id="phoneUpdate">
					</div>
							<br><br>

					<div  class="update-form" style="text-align:center">
						<label for="address"> <b>Email:</b></label>
						<input id="email" type="email" value="">
						<input type="submit" value="Update" id="emailUpdate">
					</div>
							<br><br>
				</form>

<script>
		$(".update").click(function(){
  			alert("we've sent a request for the changes, please wait");
		});

		$.post("api.php", {"action":"get_all"},function(data){
			$("#id_num").val(data.id_num);
			$("#username").val(data.username);
			$("#address").val(data.address);
			$("#balance").val(data.balance);
			$("#phone").val(data.phone);
			$("#email").val(data.email);
			console.log(data);
		});
				$("#phoneUpdate").click(function(){
					$.post("api.php", {"action":"phoneUpdate","phone":$("#phone").val()},function(data){
						console.log(data);
					});
				});

				$("#addrUpdate").click(function(){
					$.post("api.php", {"action":"addrUpdate","address":$("#address").val()},function(data){
						console.log(data);
					});
				});

				$("#emailUpdate").click(function(){
					$.post("api.php", {"action":"emailUpdate","email":$("#email").val()},function(data){
						console.log(data);
					});
				});





		</script>

	</script>
</body>
</html>
