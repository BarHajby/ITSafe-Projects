<?php

	session_start();

	/* Check if the user logged in */
    if(!isset($_SESSION["user"]))
    {
        Header("Location: ./index.php");
    }

    $user     = $_SESSION["user"];
    $userid   = $_SESSION["userid"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Main_demo</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/css/custom.css">

  <style>
  body {
  background-image: url('./assets/img/aboutus.jpg');
  background-repeat: no-repeat;
  background-size: cover;

}

#info {
  background-color: lightgrey;
  width: 650px;
	height: 600px;
  border: 15px solid black;
  padding: 50px;
	margin-left: auto;
	margin-right: auto;
	font: italic 1.2em "Fira Sans", serif;
}
h1{

font: italic small-caps bold 30px/2 cursive;

}

</style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">CLC</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="about.php">About</a></li>
      <li><a href="main.php">Main</a></li>

      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">All Topics<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="pt.php">Penetration Testing</a></li>
          <li><a href="soc.php">Soc Analyst</a></li>
          <li><a href="inv.php">Investigations(Forensics)</a></li>
          <li><a href="htb.php">HTB-Discussions</a></li>
        </ul>


      </li>

    </ul>
    <ul class="nav navbar-nav" style="float: right">
        <li><a href="#" id="logout">Logout</a></li>
    </ul>
  </div>
</nav>
<div id="info">
	<h1>Who We Are & What We Do</h1>
	<b>
	</br>
		The CLC Group Security Live Chat provides a vendor-neutral environment where Members,
		who tend to be security and risk generalist practitioners, can obtain relevant knowledge, exert influence, grow professionally,
		and network with a world-class community of experts and peers.
	</br></br>
		Our team contributors have the reputation of vigorously but cordially debating hard questions and concepts to establish next-generation risk evaluation
		and security technology approaches, methods, applications, and best practices.

	</br></br>
		We also produces general purpose intellectual property: reusable theory, principles, best practices, methods, white papers, guides,
		and standards to help suppliers and users of technology implement safe, secure, and cost-effective systems.

	</br></br>

	If you having any issues please contact me: Bhajby2012@gmail.com
	</b>

	</div>

	<script>
		$("#page").slideDown("slow");

	    $("#logout").click(function () {
	        $.post("api.php",{"action":"logout"},function () {
	            document.location="index.php";
	        });
	    });

	</script>
</body>
</html>
