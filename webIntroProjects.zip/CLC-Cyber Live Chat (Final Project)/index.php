<?php
    session_start();

    /* Check if the user already logged in */
    if(isset($_SESSION["user"]))
    {
        Header("Location: ./main.php");
    }

	$MySQLdb = new PDO("mysql:host=127.0.0.1;dbname=chat", "root", "");
    $MySQLdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if(isset($_POST['r_password']) && isset($_POST['r_username']))
    {
        $password   = $_POST['r_password'];
        $username   = $_POST['r_username'];

		$cursor = $MySQLdb->prepare("SELECT username FROM users WHERE username=:username");
		$cursor->execute( array(":username"=>$username) );

        /* New User */
        if(!($cursor->rowCount()))
		{
			$cursor = $MySQLdb->prepare("INSERT INTO users (username, password) value (:username,:password)");
			$cursor->execute(array(":password"=>$password, ":username"=>$username));
			$msg = "You have successfully registered<br>";
        }
        /* Already exists */
        else
        {
            $msg = "username already exists in the system<br>";
        }

    }
    else if(isset($_POST['l_password']) && isset($_POST['l_username']))
    {
        $password   = $_POST['l_password'];
        $username   = $_POST['l_username'];

		$cursor = $MySQLdb->prepare("SELECT * FROM users WHERE username=:username AND password=:password");
		$cursor->execute(array(":password"=>$password, ":username"=>$username));

        if(!$cursor->rowCount())
        {
            $msg = "Wrong Username/Password!<br>";
        }
        else
        {
			$return_array = $cursor->fetch();

            $_SESSION["user"]    = $return_array["username"];
            $_SESSION["userid"]  = $return_array["id"];

			/* set cookie */
            die(Header("Location: main.php"));
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login/Regsiter</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <script src="./assets/js/jquery.min.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>

    <style>
      body {
      background-image: url('./assets/img/indexx.jpg');
      background-repeat: no-repeat;
      background-size: cover;

      }
      .well{

        background-color: LightBlue;
      }
      #ko{

        background-color: LightBlue;
      }
  </style>
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="well" style="text-align: center">
                <h1>CLC - Cyber Live Chat</h1>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default" id="ko">
                <div class="panel-heading" style="text-align: center"><h4>Login/Register</h4>

                </div>
                <div class="panel-body" id="login-panel">
                    <form action="#" method="POST">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input id="l_email" type="text" class="form-control" name="l_username" placeholder="username">
                        </div>
                        <br>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input id="l_password" type="password" class="form-control" name="l_password" placeholder="password">
                        </div>
                        <br>
                        <button type="submit" class="btn btn-primary btn-block">login</button>
                        <a href="#" id="register"><i class="glyphicon glyphicon-info-sign"></i>register</a>

						<?php
							if (isset($msg))
                            {
                                echo "<div class='alert alert-default'><strong>Error:</strong>".$msg."</div>";
                            }
						?>
                    </form>
                </div>
                <div class="panel-body" id="register-panel" hidden>
                    <form action="#" method="POST">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input id="r_username" type="text" class="form-control" name="r_username" placeholder="username">
                        </div>
                        <br>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input id="r_password" type="password" class="form-control" name="r_password" placeholder="password">
                        </div>
                        <br>
                        <button type="submit" class="btn btn-primary btn-block">register</button>
                        <a href="#" id="login"><i class="glyphicon glyphicon-info-sign"></i>login</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
$("#register").click(function () {
    $("#login-panel").fadeOut(1000);
    $("#register-panel").delay(1000).fadeIn(1000);
});
$("#login").click(function () {
    $("#register-panel").fadeOut(1000);
    $("#login-panel").delay(1000).fadeIn(1000);
});
</script>
</body>
</html>
