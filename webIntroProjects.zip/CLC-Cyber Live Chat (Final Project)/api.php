<?php
    session_start();

    $userid = $_SESSION["userid"];
    $username = $_SESSION["user"];

    $MySQLdb = new PDO("mysql:host=127.0.0.1;dbname=chat", "root", "");
    $MySQLdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $action = $_POST["action"];
    if (isset ($_POST["data"])){
      $data = $_POST["data"];
    }
    /* we will return json */
    header('Content-Type: application/json');
    switch ($action)
    {
        case "get_all_posts_htb":
            $cursor = $MySQLdb->prepare("SELECT * FROM posts");
            $cursor->execute();
            $retval = "";

            foreach ($cursor->fetchAll() as $row) {
              if ($row["user_id"] == $userid) {
                $retval = $retval . "<div class='media'><div class='media-body text-right' ><h4 class='media-heading'>".$username."</h4><p>".$row['post_data']."</p></div><div class='media-right'><img src='profile.png' class='media-object' style='width:60px'></div></div>";
              }else{
                $retval = $retval . "<div class='media'><div class='media-left'><img src='profile.png' class='media-object' style='width:60px'></div><div class='media-body'><h4 class='media-heading'>".$row['user_name']."</h4><p>".$row['post_data']."</p></div></div>";
              }
            }
            echo '{"success":"true","data":"'.$retval.'"}';
            die();

            break;

        case "get_all_posts_inv":
            $cursor = $MySQLdb->prepare("SELECT * FROM postss");
            $cursor->execute();
            $retval = "";

            foreach ($cursor->fetchAll() as $row) {
              if ($row["user_id"] == $userid) {
                $retval = $retval . "<div class='media'><div class='media-body text-right' ><h4 class='media-heading'>".$username."</h4><p>".$row['post_data']."</p></div><div class='media-right'><img src='profile.png' class='media-object' style='width:60px'></div></div>";
              }else{
                $retval = $retval . "<div class='media'><div class='media-left'><img src='profile.png' class='media-object' style='width:60px'></div><div class='media-body'><h4 class='media-heading'>".$row['user_name']."</h4><p>".$row['post_data']."</p></div></div>";
              }
            }
            echo '{"success":"true","data":"'.$retval.'"}';
            die();

            break;

        case "get_all_posts_soc":
            $cursor = $MySQLdb->prepare("SELECT * FROM postsss");
            $cursor->execute();
            $retval = "";

            foreach ($cursor->fetchAll() as $row) {
              if ($row["user_id"] == $userid) {
                $retval = $retval . "<div class='media'><div class='media-body text-right' ><h4 class='media-heading'>".$username."</h4><p>".$row['post_data']."</p></div><div class='media-right'><img src='profile.png' class='media-object' style='width:60px'></div></div>";
              }else{
                $retval = $retval . "<div class='media'><div class='media-left'><img src='profile.png' class='media-object' style='width:60px'></div><div class='media-body'><h4 class='media-heading'>".$row['user_name']."</h4><p>".$row['post_data']."</p></div></div>";
              }
            }
            echo '{"success":"true","data":"'.$retval.'"}';
            die();

            break;

        case "get_all_posts_pt":
            $cursor = $MySQLdb->prepare("SELECT * FROM postssss");
            $cursor->execute();
            $retval = "";

            foreach ($cursor->fetchAll() as $row) {
              if ($row["user_id"] == $userid) {
                $retval = $retval . "<div class='media'><div class='media-body text-right' ><h4 class='media-heading'>".$username."</h4><p>".$row['post_data']."</p></div><div class='media-right'><img src='profile.png' class='media-object' style='width:60px'></div></div>";
              }else{
                $retval = $retval . "<div class='media'><div class='media-left'><img src='profile.png' class='media-object' style='width:60px'></div><div class='media-body'><h4 class='media-heading'>".$row['user_name']."</h4><p>".$row['post_data']."</p></div></div>";
              }
            }
            echo '{"success":"true","data":"'.$retval.'"}';
            die();

            break;

        // htb new post
        case "new_post":

            $cursor = $MySQLdb->prepare("INSERT INTO posts (user_id,post_data,user_name) value (:id,:post_data,:name)");
            $cursor->execute(array(":id"=>$userid, ":post_data"=>$data,":name"=>$username));
            if ($cursor->rowCount())  die('{"success":true}');
            else die('{"success":false}');
            break;

        //investigation new post
        case "new_post2":

            $cursor = $MySQLdb->prepare("INSERT INTO postss (user_id,post_data,user_name) value (:id,:post_data,:name)");
            $cursor->execute(array(":id"=>$userid, ":post_data"=>$data,":name"=>$username));
            if ($cursor->rowCount())  die('{"success":true}');
            else die('{"success":false}');
            break;
        //soc new post
        case "new_post3":

            $cursor = $MySQLdb->prepare("INSERT INTO postsss (user_id,post_data,user_name) value (:id,:post_data,:name)");
            $cursor->execute(array(":id"=>$userid, ":post_data"=>$data,":name"=>$username));
            if ($cursor->rowCount())  die('{"success":true}');
            else die('{"success":false}');
            break;

          //pt new post
        case "new_post4":

            $cursor = $MySQLdb->prepare("INSERT INTO postssss (user_id,post_data,user_name) value (:id,:post_data,:name)");
            $cursor->execute(array(":id"=>$userid, ":post_data"=>$data,":name"=>$username));
            if ($cursor->rowCount())  die('{"success":true}');
            else die('{"success":false}');
            break;



        case "logout":
            session_destroy();
            die('{"success":true}');
            break;

        default:
            die('{"success":false}');
    }
