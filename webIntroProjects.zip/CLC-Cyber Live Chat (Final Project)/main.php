<?php

	session_start();

	/* Check if the user logged in */
    if(!isset($_SESSION["user"]))
    {
        Header("Location: ./index.php");
    }

    $user     = $_SESSION["user"];
    $userid   = $_SESSION["userid"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Main_demo</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/css/custom.css">

  <style>
  body {
  background-image: url('./assets/img/back.jpg');
  background-repeat: no-repeat;
  background-size: cover;

}
.jumbotron{
  background-color: LightSeaGreen	;
  text-align: center;
  border-color: LightBlue;
}

</style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">CLC</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Main</a></li>

      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">All Topics<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="pt.php">Penetration Testing</a></li>
          <li><a href="soc.php">Soc Analyst</a></li>
          <li><a href="inv.php">Investigations(Forensics)</a></li>
          <li><a href="htb.php">HTB-Discussions</a></li>
        </ul>
        <li><a href="about.php">About us</a></li>

      </li>

    </ul>
    <ul class="nav navbar-nav" style="float: right">
        <li><a href="#" id="logout">Logout</a></li>
    </ul>
  </div>
</nav>


<div class="jumbotron" style="text-align:center">
  <h1 class="display-1">Welcome to CLC (Cyber Live Chat)</h1>
  <h3 class="display-3">Please choose topic from above to start Chatting..</h3>
</div>
</div>


</div>

<div class="container" style="text-align:center">
  <div class="jumbotron">
    <h1>Username: <?php echo $user; ?></h1>
    <h1>IP: <?php echo $_SERVER["REMOTE_ADDR"]; ?></h1>
  </div>
</div>


<script>
	$("#page").slideDown("slow");

    $("#logout").click(function () {
        $.post("api.php",{"action":"logout"},function () {
            document.location="index.php";
        });
    });

</script>
</body>
</html>
