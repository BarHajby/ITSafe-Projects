<?php

	session_start();

	/* Check if the user logged in */
    if(!isset($_SESSION["user"]))
    {
        Header("Location: ./index.php");
    }

    $user     = $_SESSION["user"];
    $userid   = $_SESSION["userid"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Forum</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/css/custom.css">

    <script src="./assets/js/jquery.min.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
		<style>
	  body {
	  background-image: url('./assets/img/pt.png');
	  background-repeat: no-repeat;
	  background-size: cover;

	}

	</style>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">CLC-Cyber Live Chat</a>
						<ul class="nav navbar-nav">
							<li><a href="main.php">Main</a></li>
						<li class="active"><a href="pt.php">Penetration Testing</a></li>

			      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">All Topics<span class="caret"></span></a>
			        <ul class="dropdown-menu">
			          <li><a href="pt.php">Penetration Testing</a></li>
			          <li><a href="soc.php">Soc Analyst</a></li>
			          <li><a href="inv.php">Investigations(Forensics)</a></li>
			          <li><a href="htb.php">HTB-Discussions</a></li>
			        </ul>
			        <li><a href="about.php">About us</a></li>
        </div>

        <ul class="nav navbar-nav" style="float: right">
            <li><a href="#" id="logout">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <div class="row" id="page" hidden>
        <div class="col-md-3">
            <div class="panel panel-default">
                <div class="panel-heading">Account Info</div>
                <div class="panel-body">
                    <ul class="list-group">
                        <li class="list-group-item">
                            <p>
                                <kbd>username:</kbd>
                                <span style="float:right;">
                                    <?php echo $user; ?>
                                </span>
                            </p>
                        </li>
                        <li class="list-group-item">
                            <p>
                                <kbd>ip address</kbd>
                                <span style="float:right;">
                                    <?php echo $_SERVER["REMOTE_ADDR"];?>
                                </span>
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Chat History
                </div>
                <div class="panel-body">
                    <ul class="list-group" id="post_history">

                    </ul>
                </div>
            </div>
            <div class="input-group">
                <input id="msg" type="text" class="form-control" name="msg" placeholder="Write your message here...">
                <span class="input-group-addon"><button id="send_post">Send</button></span>
            </div>
        </div>
    </div>
</div>
<script>
	$("#page").slideDown("slow");

    $("#logout").click(function () {
        $.post("api.php",{"action":"logout"},function () {
            document.location="index.php";
        });
    });

		$.post("api.php",{"action":"get_all_posts_pt"},function (data) {
			if(data.success == "true"){
				$("#post_history").html(data.data);
			}
		});

	$("#send_post").click(function () {
		$.post("api.php",{"action":"new_post4","data":msg.value},function (data) {
			document.location.reload();
		});
	});

</script>
</body>
</html>
