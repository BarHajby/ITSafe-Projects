-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: דצמבר 11, 2022 בזמן 12:35 PM
-- גרסת שרת: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chat`
--

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `posts`
--

CREATE TABLE `posts` (
  `post_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `post_data` text NOT NULL,
  `user_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- הוצאת מידע עבור טבלה `posts`
--

INSERT INTO `posts` (`post_id`, `user_id`, `post_data`, `user_name`) VALUES
(6, 2, 'Welcome to the private community of cyber Discussions. how can we help?', 'admin');

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `postss`
--

CREATE TABLE `postss` (
  `post_id` int(11) NOT NULL,
  `user_id` int(10) NOT NULL,
  `post_data` varchar(500) NOT NULL,
  `user_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- הוצאת מידע עבור טבלה `postss`
--

INSERT INTO `postss` (`post_id`, `user_id`, `post_data`, `user_name`) VALUES
(3, 2, 'Welcome to the private community of cyber Discussions. how can we help?', 'admin');

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `postsss`
--

CREATE TABLE `postsss` (
  `post_id` int(11) NOT NULL,
  `user_id` int(10) NOT NULL,
  `post_data` varchar(500) NOT NULL,
  `user_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- הוצאת מידע עבור טבלה `postsss`
--

INSERT INTO `postsss` (`post_id`, `user_id`, `post_data`, `user_name`) VALUES
(3, 2, 'Welcome to the private community of cyber Discussions. how can we help?', 'admin');

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `postssss`
--

CREATE TABLE `postssss` (
  `post_id` int(11) NOT NULL,
  `user_id` int(10) NOT NULL,
  `post_data` varchar(500) NOT NULL,
  `user_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- הוצאת מידע עבור טבלה `postssss`
--

INSERT INTO `postssss` (`post_id`, `user_id`, `post_data`, `user_name`) VALUES
(3, 2, 'Welcome to the private community of cyber Discussions. how can we help?', 'admin');

-- --------------------------------------------------------

--
-- מבנה טבלה עבור טבלה `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- הוצאת מידע עבור טבלה `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'bar', 'bar123'),
(2, 'admin', 'admin123'),
(3, 'johnny', 'johnny123');

--
-- Indexes for dumped tables
--

--
-- אינדקסים לטבלה `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- אינדקסים לטבלה `postss`
--
ALTER TABLE `postss`
  ADD PRIMARY KEY (`post_id`);

--
-- אינדקסים לטבלה `postsss`
--
ALTER TABLE `postsss`
  ADD PRIMARY KEY (`post_id`);

--
-- אינדקסים לטבלה `postssss`
--
ALTER TABLE `postssss`
  ADD PRIMARY KEY (`post_id`);

--
-- אינדקסים לטבלה `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `postss`
--
ALTER TABLE `postss`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `postsss`
--
ALTER TABLE `postsss`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `postssss`
--
ALTER TABLE `postssss`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
